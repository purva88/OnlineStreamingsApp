package com.app.test;

import java.util.List;
import java.util.Scanner;
import java.util.function.Consumer;

import com.app.dao.USerDao;
import com.app.factory.UserFactory;
import com.app.model.Package;
import com.app.model.User;
import com.app.util.HibernateUtil;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sn=new Scanner(System.in);
USerDao dao=UserFactory.getUser();
String ch="";
do {
	System.out.println("Welcome To My Project");
	System.out.println("Press 1: for Register");
	System.out.println("Press 2: for Login");
	System.out.println("Press 3: for Display Users");
	System.out.println("Press 4: for Display User on id");
	System.out.println("-------------------------------");
	System.out.println("Enter Your Choice:");
	int choice=sn.nextInt();
	switch (choice) {
	case 1:
		int i=dao.register();
		if(i==1) {
			System.out.println("Successfully Register");
			
		}else {
			System.out.println("Something went wrong...!");
		}
		break;
	case 2:
		User user=dao.login();
		if(user!=null &&user.getRole().equalsIgnoreCase("admin")) {
			System.out.println("welcome to admin portal.");
		}else if(user!=null &&user.getRole().equalsIgnoreCase("user")){
			System.out.println("Welcome to User Portal..");
		}else {
			System.out.println("LOGED IN SUCCESSFULLY");
		}
		System.out.println("Select your choice :");
		System.out.println("Press 1: to see your details");
		System.out.println("Press 2: Packages");
		int n =sn.nextInt();
		
		if(n==1)
		{
			System.out.println("Enter your id to see your details:");
			int id=sn.nextInt();
			User u1=dao.findById(id);
			System.out.println(u1);
			break;
		}
		if(n==2)
		{
			
			
				System.out.println("select Packages : ");
				List<Package>allpackage=dao.listOfPackage(); 
				allpackage.stream().forEach(s->System.out.println(s.getPid()+"\t"+s.getPackageName()+"\t"+s.getDuration()+"\t"+s.getPrice()));
				System.out.println("please enter package id");
				int pid=sn.nextInt();
				Package p=dao.findByPackage(pid);
				System.out.println(p);
		}
				/*System.out.println("Entertainment package");
				System.out.println("Movies package");
				System.out.println("Music package");
				System.out.println("Kids package");
				System.out.println("News package");
				System.out.println("Enter your package name");
				
			
			
						
			
			if(n==3)
			{
				System.out.println("Select Subscription Duration:");
				System.out.println("Press 1: Monthly ");
				System.out.println("Press 2: Yearly");
				
			}
			*/	
			else {
				System.out.println("invalid choice");
			}
		
		
		
		break;
	case 3:
		List<User>list=dao.listOfUsers();
		list.stream().forEach(new Consumer<User>() {
			public void accept(User s) {
				System.out.println(s.getId()+"\t"+s.getFisrtName()+" "+s.getLastName()+"\t"+s.getAddress()+"\t"+s.getMobile());
			}
		});
	break;
	case 4:
		System.out.println("Enter your id for find user:");
		int id=sn.nextInt();
		User u1=dao.findById(id);
		System.out.println(u1);
		break;
	default:
		System.out.println("Invalid Request...!");
		break;
	}
	System.out.println("Do you want to continue...(y)");
	ch=sn.next();
}while(ch.equalsIgnoreCase("y"));
System.out.println("Thank you");
	}

}
