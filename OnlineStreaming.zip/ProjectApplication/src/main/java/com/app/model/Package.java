package com.app.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;

@Entity
public class Package {
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	
	private int pid;
	private String PackageName;
	private String Duration;
	private double Price;
	private List<User> user;
	 @OneToMany(targetEntity = User.class)
	  @JoinTable(name="User_Subscription",joinColumns= @JoinColumn(name="pid"),inverseJoinColumns = @JoinColumn(name="id"))
	  
	public int getPid() {
		return pid;
	}
	public void setSid(int pid) {
		this.pid = pid;
	}
	public String getPackageName() {
		return PackageName;
	}
	public void setPackageName(String packageName) {
		PackageName = packageName;
	}
	public String getDuration() {
		return Duration;
	}
	public void setDuration(String duration) {
		Duration = duration;
	}
	
	public double getPrice() {
		return Price;
	}
	public void setPrice(double price) {
		Price = price;
	}
	public List<User> getUser() {
		return user;
	}
	public void setUser(List<User> user) {
		this.user = user;
	}
	
	public Package(int pid, String packageName, String duration, double price, List<User> user) {
		super();
		this.pid = pid;
		PackageName = packageName;
		Duration = duration;
		Price = price;
		this.user = user;
	}
	public Package() {
		super();
	}
	@Override
	public String toString() {
		return "Package [pid=" + pid + ", PackageName=" + PackageName + ", Duration=" + Duration + ", Price=" + Price
				+ ", user=" + user + "]";
	}
	
	 


}
