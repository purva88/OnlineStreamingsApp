package com.app.dao;

import java.util.List;

import com.app.dto.UserRequest;
import com.app.model.Package;
import com.app.model.User;

public interface USerDao {
int register();
User login();
List<User> listOfUsers();
User findById(int id);
List<Package> listOfPackage();
Package findByPackage(int pid);
}
